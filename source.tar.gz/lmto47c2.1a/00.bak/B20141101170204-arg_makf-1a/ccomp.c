/*  Conditional compilation of FORTRAN programs                                 
                                                                                
C#ifdef, C#ifndef, C#else, C#elseif, C#endif                                    
                                                                                
A preprocessor, ccomp, provides a simplified, FORTRAN compatible version        
of C conditional compilation.  FORTRAN statements beginning with C# are         
preprocessor directives; the ones implemented now are C#ifdef, C#ifndef,        
C#else, C#elseif, C#endif (also C#define defines a name).  Directives           
C#ifdef, C#ifndef, C#elseif, and C#endif are followed by a name, eg             
C#ifdef CRAY.  when C#ifdef is false (either name is not defined or it          
lies within an #if/#endif block that is false), ccomp comments out until        
a change of state (new C#ifdef, C#ifndef, C#else, C#elseif, C#endif             
encountered); C#ifdef is true, ccomp uncomments lines following until           
another conditional compilation directive is encountered.                       
                                                                                
Conditional compilation blocks may be nested.  As with C, ccomp                 
distinguishes case.  Output is to standard out.                                 
                                                                                
There is a primitive facility to make logical expressions using the AND         
(&) and OR (|) operators, such C#ifdef john & bill, or C#ifdef john |           
bill, is provided.  Precedence of operators is strictly left to right,          
so that john | bill & mike is equivalent to (john | bill) & mike,               
whereas john & bill | mike is equivalent to (john & bill) | mike                
                                                                                
How ccomp determines whether to modify code:                                    
                                                                                
Whether the lines following a C#ifdef, C#ifndef, C#else, C#elseif,              
C#endif need to be commented out or uncommented depends on whether they         
have been commented out in a previous pass.  This information is                
contained in a 'C' following the directive, eg C#ifdefC, C#ifndefC,             
C#elseC, C#elseifC, C#endifC.  The preprocessor will set this, it is            
best advised to create any new blocks uncommented and let the                   
preprocessor do the commenting.                                                 
                                                                                
*/                                                                              
                                                                                
#include <stdio.h>                                                            
                                                                                
#define MSDOS                                                                   
#define COMMENT   1                                                             
#define UNCOMMENT 0                                                             
                                                                                
/* switches: */                                                                 
int Options;                                                                    
#define FILTER 2                                                                
                                                                                
/* Rules of operation:                                                          
  A new conditional is encountered by a C#ifdef (or C#elseif or C#else)         
  Every time a new conditional is encountered, the following is determined:     
                                                                                
  Conditional compilation is in one of two states:                              
    COMMENT:   should be commented                                              
    UNCOMMENT: should be uncommented                                            
  Previous condition is in one of two states:                                   
    COMMENT:   was commented                                                    
    UNCOMMENT: was uncommented                                                  
                                                                                
  The previous condition defaults to state UNCOMMENT, unless explicitly         
  specified by appending a C to the conditional, eg: C#ifdef goes to C#ifdefC,  
  etc.  This will be done by ccomp if it comments something through a           
  pass, and is not normally done manually.                                      
 */                                                                             
                                                                                
struct nest_table                                                               
{                                                                               
  int num;                                                                      
  char truth[10];                                                               
  char truthe[10];                                                              
};                                                                              
                                                                                
#define LEAVE 0                                                                 
#define ADDC 1                                                                  
#define REMOVEC 3                                                               
                                                                                
char *fexts();                                                                  
                                                                                
char s[256];                                                                    
short qchange;                                                                  
int lineno;                                                                     
char dlist[256],ulist[256];                                                     
char *pdlist,*pulist;                                                           
short ndef=0,nudef=0;                                                           
                                                                                
#define INIT_PTR_LIST {pdlist=dlist; pulist=ulist;}                             
                                                                                
void movmem();                                                                  
                                                                                
main(argc,argv)                                                                 
short argc; char *argv[];                                                       
{                                                                               
  char srcnam[80],dstnam[80],olddir[80];                                        
  FILE *Source; FILE *Dest;                                                     
  short iarg;                                                                   
                                                                                
/*--- set initial options ---*/                                                 
  Options = 0;                                                                  
  Dest = stdout;                                                                
                                                                                
  INIT_PTR_LIST;                                                                
                                                                                
/*--- get source file name and switches --- */                                  
  iarg = 0;                                                                     
  do {if (iarg >= argc) Error();} while (sw(argv[++iarg]));                     
 if (Options & FILTER) Source = stdin; else strcpy(srcnam,argv[iarg++]);        
                                                                                
  if (!fexts(srcnam)) strcat(srcnam," for");                                    
                                                                                
/* get the destination file name, if there is one */                            
  if (iarg != argc) {                                                           
    strcpy(dstnam,argv[iarg++]); /* strcat(dstnam," for"); */  
    if (iarg != argc) Error();                                                  
    printf("ccomp: file %s to %s\n",srcnam,dstnam);                             
    Dest = fopen(dstnam,"w");                                                   
  }                                                                             
                                                                                
/*--- open the source file ---*/                                                
  if (!(Options & FILTER)) {                                                    
    if ((Source=fopen(srcnam,"r")) == NULL) Error();                            
  }                                                                             
                                                                                
  ccomp(Source,Dest);                                                           
}                                                                               
                                                                                
#define max(a,b)   ((a) > (b) ? (a) : (b))                                      
                                                                                
ccomp(Source,Dest)                                                              
FILE *Source,*Dest;                                                             
{                                                                               
  struct nest_table nest;                                                       
  int i,nmov,change_state;                                                      
  char cntrl[40],name[40],*ps,*psC,*psO,*pdlist;                                
  short prevdef;                                                                
                                                                                
  s[0] = 'c';                                                                   
  nest.truthe[0] = nest.truth[0] = UNCOMMENT;                                   
  change_state = LEAVE;                                                         
  qchange = lineno = nest.num = 0;                                              
                                                                                
/*prints out all #define to stdout and sets up pdlist */                        
  for (i=ndef, pdlist=dlist; i--;) {                                            
    fprintf(Dest,"C#define %s\n",pdlist); pdlist += strlen(pdlist)+1;           
  }                                                                             
                                                                                
  while(ps=s+1,fgets(ps,255,Source)) {                                          
    lineno++;                                                                   
    if ((*ps=='c' || *ps=='C') && *(ps+1)=='#') {                               
      psC = ps; name[0] = '\0'; sscanf(ps+2,"%s %s",cntrl,name);                
      if (!strcmp(cntrl,"define")) {                                            
        if (among(ulist,nudef,name)) continue;                                  
        strcat(pdlist,name); pdlist += strlen(pdlist)+1; ndef++;                
      }                                                                         
      else if (!strncmp(cntrl,"ifndef",6)) {                                    
        psC = ps+6;                                                             
/*      Push this condition onto stack */                                       
        nest.truthe[nest.num+1] = nest.truth[nest.num];                         
        nest.num++;                                                             
        nest.truth[nest.num] =                                                  
          ((nest.truthe[nest.num] == COMMENT) || match(psC)) ?                  
          COMMENT: UNCOMMENT;                                                   
      }                                                                         
      else if (!strncmp(cntrl,"ifdef",5)) {                                     
        psC = ps+5;                                                             
/*      Push this condition onto stack */                                       
        nest.truthe[nest.num+1] = nest.truth[nest.num];                         
        nest.num++;                                                             
        nest.truth[nest.num] =                                                  
          ((nest.truthe[nest.num] == COMMENT) || !match(psC)) ?                 
          COMMENT: UNCOMMENT;                                                   
      }                                                                         
      else if (!strncmp(cntrl,"elseif",6)) {                                    
        psC = ps+6;                                                             
        if (!nest.num) errchk("ccomp: #elseif found before #ifdef");            
if (nest.truth[nest.num] == UNCOMMENT) nest.truthe[nest.num] = COMMENT;         
        nest.truth[nest.num] =                                                  
          ((nest.truthe[nest.num] == COMMENT) || !match(psC)) ?                 
          COMMENT: UNCOMMENT;                                                   
      }                                                                         
      else if (!strncmp(cntrl,"else",4)) {                                      
        psC = ps+4;                                                             
        if (!nest.num) errchk("ccomp: #else found before #ifdef");              
if (nest.truth[nest.num] == UNCOMMENT) nest.truthe[nest.num] = COMMENT;         
        nest.truth[nest.num] =                                                  
          ((nest.truthe[nest.num] == COMMENT)) ?                                
          COMMENT: UNCOMMENT;                                                   
      }                                                                         
      else if (!strncmp(cntrl,"endif",5)) {                                     
        psC = ps+5;                                                             
        if (!nest.num--) errchk("ccomp: #endif found before #ifdef");           
      }                                                                         
                                                                                
/*    Check for a change of state */                                            
      if (ps != psC) {                                                          
        psC += 2;                                                               
        change_state = LEAVE;                                                   
if (((*psC == 'C'|| *psC == 'c') 
        ? COMMENT: UNCOMMENT) ^ nest.truth[nest.num]){               
          psO = ps;                                                             
          nmov = psC - ps;                                                      
/* shift right, eg C#ifdefC to _C#ifdef;  or left, eg _C#ifdef becomes C#ifdefC 
 */                                                                             
          if (nest.truth[nest.num] == COMMENT) {                                
            change_state = ADDC;                                                
            ps -= 1;                                                            
          }                                                                     
          else {                                                                
            change_state = REMOVEC;                                             
            ps += 1; psC += 1;                                                  
          }                                                                     
          movmem(psO,ps,nmov);                                                  
          if (nest.truth[nest.num] == COMMENT) *(psC-1) = 'c';                  
        }                                                                       
      }                                                                         
    }                                                                           
    else {                                                                      
      if (!nest.num && change_state != LEAVE)                                   
errchk("ccomp: not within conditional compilation but changing state");         
      switch(change_state) {                                                    
#ifdef DEBUG                                                                    
        case ADDC: ps = "add comment\r\n"; break;                               
        case REMOVEC: ps = "remove comment\r\n"; break;                         
        case LEAVE: ps = "leave as is\r\n";                                     
#else                                                                           
        case ADDC: ps -= 1; *ps = 'c'; break;                                   
        case REMOVEC: if (*ps == 'c' || *ps == 'C') {ps += 1; break;}           
                      else errchk("ccomp: Line begins without comment");        
#endif                                                                          
      }                                                                         
    }                                                                           
    fputs(ps,Dest);                                                             
  }                                                                             
}                                                                               
                                                                                
#include <ctype.h>                                                              
                                                                                
match(psC)                                                                      
char *psC;                                                                      
{                                                                               
  char nam[64];                                                                 
  int state[20],op[20],i,j,res;                                                 
                                                                                
  next_wor(&psC,nam);                                                           
  i = -1;                                                                       
  do {                                                                          
    i++;                                                                        
    next_wor(&psC,nam);                                                         
state[i] = (nam[0] == '!') ? among(dlist,ndef,nam+1):                           
 among(dlist,ndef,nam);                                                         
    next_wor(&psC,nam);                                                         
                                                                                
  } while ((op[i]=1,!strcmp(nam,"|")) || (op[i]=2,!strcmp(nam,"&")));           
                                                                                
  for (j=0,res=state[0]; j<i; j++) {                                            
    if (op[j] == 1) res |= state[j+1];                                          
    else if (op[j] == 2) res &= state[j+1];                                     
  }                                                                             
                                                                                
/*  printf("match %d %d\n",i,res);*/                                            
                                                                                
  return (res);                                                                 
}                                                                               
                                                                                
next_wor(psC,nam)                                                               
char **psC,*nam;                                                                
{                                                                               
  while (isspace(**psC)) (*psC)++;                                              
  while (!isspace(**psC)) {if (!(*nam++ = **psC)) break; (*psC)++;}             
  *nam = '\0';                                                                  
}                                                                               
among(list,nlist,name)                                                          
char *list,*name;                                                               
{                                                                               
  while (nlist-- > 0) {                                                         
    if (!strcmp(name,list)) return(1);                                          
    list += strlen(list)+1;                                                     
  }                                                                             
  return(0);                                                                    
}                                                                               
                                                                                
errchk (string)                                                                 
  char *string;                                                                 
{                                                                               
  if (string) {                                                                 
    fprintf(stderr,"%d %s",lineno,string);                                      
    exit (-1);                                                                  
  }                                                                             
}                                                                               
                                                                                
sw(s)                                                                           
char *s;                                                                        
{                                                                               
  if (*s++ != '-') return(0);                                                   
  switch(*s++) {                                                                
    case 'f': Options |= FILTER; break;                                         
    case 'd': sscanf(s,"%s",pdlist); pdlist += strlen(pdlist)+1; ndef++;        
              break;                                                            
  case 'u': sscanf(s,"%s",pulist); pulist += strlen(pulist)+1; nudef++;         
              break;                                                            
    default: Error();                                                           
  }                                                                             
  return(1);                                                                    
}                                                                               
                                                                                
Error()                                                                         
{                                                                               
  printf("usage: ccomp [-dn] filename[.for] [dest-name]\n%s%s"                  
        ,"              -dname defines name\n"                                  
        ,"              -uname undefs name\n"                                   
        );                                                                      
  exit(1);                                                                      
}                                                                               
                                                                                
void movmem(ps,pd,len)                                                          
char *ps,*pd; int len;                                                          
{                                                                               
  if (ps > pd) {while(len--) *pd++ = *ps++;}                                    
  else {ps += len; pd += len; while(len--) *--pd = *--ps;}                      
}                                                                               
                                                                                
#ifdef TEST                                                                     
main()                                                                          
{                                                                               
  char *ps,*pd;                                                                 
  ps = "abcdefghi";                                                             
  pd = ps+2;                                                                    
  movmem(ps,pd,3); printf("ps and pd are %s %s\n",ps,pd);                       
  pd = "abcdefghi";                                                             
  ps = pd+2;                                                                    
  movmem(ps,pd,3); printf("ps and pd are %s %s\n",ps,pd);                       
}                                                                               
#endif                                                                          
                                                                                
/* fexts finds an extension to a file name.                                     
   returns NULL if no extension was found, a pointer to extension if found      
 */                                                                             
                                                                                
char *fexts(fname)                                                              
register char *fname;                                                           
{                                                                               
  register short extlen;                                                        
  register char *pnam;                                                          
                                                                                
#ifdef MSDOS                                                                    
#define EXTCHR '.'                                                              
#define MAXEXT 4                                                                
#endif                                                                          
                                                                                
  if ((pnam=fname+(extlen=strlen(fname))) == fname) return(NULL);               
  extlen = (extlen > MAXEXT) ? MAXEXT: extlen;                                  
  while(extlen--) if (*--pnam == EXTCHR) return(pnam+1);                        
  return(NULL);                                                                 
}                                                                               
